package mdp.group.ch;


import mdp.group.ch.entitys.DataCollection;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.logging.Logger;

@Component
public class Consumer {

    private final Logger logger = Logger.getLogger(Consumer.class.getName());


    @Autowired
    DataRepository repo;

    @KafkaListener(topics = "${KAFKA_TOPICS}", groupId = "${KAFKA_GROUP_ID}")
    public void consume(@Payload ConsumerRecord<String, String> message) throws IOException {

        logger.info("Consum Message with OFFSET :" + message.offset());

        DataCollection dc = new DataCollection();
        dc.setOffset(message.offset());
        dc.setData(message.value());
        repo.save(dc);

    }

}