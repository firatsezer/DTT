package mdp.group.ch;

import mdp.group.ch.entitys.Log;
import org.springframework.data.repository.CrudRepository;

public interface LogRepository extends CrudRepository<Log, Integer> {
}
